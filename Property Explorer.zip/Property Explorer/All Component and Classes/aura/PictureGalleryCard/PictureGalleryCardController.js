({
    doInit : function(component) {
    	// Hardcoding images in this demo component
    	component.set("v.slides", [
            'https://drec--drecpoc--c.visualforce.com/resource/1588142494000/DREC_livingRoom?',
            'https://drec--drecpoc--c.visualforce.com/resource/1588142530000/DREC_kitchen',
			'https://drec--drecpoc--c.visualforce.com/resource/1588142584000/DREC_EatingKitchen?'
        ]);
    },

	fullScreen : function(component) {
        component.set("v.fullScreen", true);
	},

	closeDialog : function(component) {
        component.set("v.fullScreen", false);
	}

})